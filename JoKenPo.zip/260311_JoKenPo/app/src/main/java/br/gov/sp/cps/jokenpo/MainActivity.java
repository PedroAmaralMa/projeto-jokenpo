package br.gov.sp.cps.jokenpo;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Selecionada Pedra:
    public void selecPedra(View view){
        this.opcaoSelecionada("pedra");
    }

    // Selecionada Papel:
    public void selecPapel(View view){
        this.opcaoSelecionada("papel");
    }

    // Selecionada Tesoura:
    public void selecTesoura(View view){
        this.opcaoSelecionada("tesoura");
    }

    public void resetar(View view){
        ImageView imgResultado = findViewById(R.id.imgResultado);
        TextView textResultado = findViewById(R.id.textResultado);
        TextView pontosPC = findViewById(R.id.textPCPlacar);
        TextView pontosYOU = findViewById(R.id.textYOUPlacar);

        imgResultado.setImageResource(R.drawable.padrao);
        textResultado.setText("Escolha sua opção:");
        pontosPC.setText("0");
        pontosYOU.setText("0");
    }

    // Analise das Opções Selecionadas e Jogadas:
    public void opcaoSelecionada(String opcaoSelecionada){
        TextView pontosPC = findViewById(R.id.textPCPlacar);
        TextView pontosYOU = findViewById(R.id.textYOUPlacar);
        int qtdPontosPC = Integer.parseInt(pontosPC.getText().toString());
        int qtdPontosYOU = Integer.parseInt(pontosYOU.getText().toString());
        if (qtdPontosYOU == 5 || qtdPontosPC == 5){
            return;
        }
        ImageView imgResultado = findViewById(R.id.imgResultado);
        TextView textResultado = findViewById(R.id.textResultado);


        // Logica - Escolha do PC:
        int numero = new Random().nextInt(3);
        String[] opcoes = {"pedra", "papel", "tesoura"};
        String opcaoPC = opcoes[numero];

        // Muda a figura (escolha do PC):
        switch (opcaoPC) {
            case "pedra":
                imgResultado.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imgResultado.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imgResultado.setImageResource(R.drawable.tesoura);
                break;

        }


        // Logica do Jogo - Analisa quem ganhou e quem perdeu:
        if (
                (opcaoPC == "tesoura" && opcaoSelecionada == "papel") ||
                (opcaoPC == "papel" && opcaoSelecionada == "pedra")   ||
                (opcaoPC == "pedra" && opcaoSelecionada == "tesoura")
        ){
            qtdPontosPC++;
            pontosPC.setText(String.format("%d", qtdPontosPC));
            if(qtdPontosPC == 5){
                imgResultado.setImageResource(R.drawable.beta);
                textResultado.setText("PC WIN - Não Sobrou Nada para o Beta");
            } else {
                textResultado.setText("PC WIN - Perdeu Mane!");
            }


        } else if(

                (opcaoSelecionada == "tesoura" && opcaoPC == "papel") ||
                (opcaoSelecionada == "papel" && opcaoPC == "pedra")   ||
                (opcaoSelecionada == "pedra" && opcaoPC == "tesoura")
        ) {
            qtdPontosYOU++;
            pontosYOU.setText(String.format("%d", qtdPontosYOU));
            if (qtdPontosYOU == 5){
                imgResultado.setImageResource(R.drawable.parabens);
                textResultado.setText("YOU WIN - Parabéns Beta....");
            } else {
                textResultado.setText("YOU WIN - Mané...");
            }

        } else {
            textResultado.setText("Empatou - Dois Patos");

        }



    }
}